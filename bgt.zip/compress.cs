using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;

class RLECompression
{

    static List<byte> ResultFile = new List<byte>();
    static int OrFLen = 0;
    public static void Compress(byte[] data)
    {
        int length = data.Length;
        int i = 0;

        while (i < length)
        {
            byte currentByte = data[i];
            byte count = 1;

            while (i + 1 < length && data[i + 1] == currentByte)
            {
                count++;
                i++;

                if (count == 0)
                {
                    break; // máximo valor de byte
                }
            }

            ResultFile.Add((byte)count);
            ResultFile.Add(currentByte);

            Console.WriteLine(Convert.ToString(currentByte, 16) + " " + Convert.ToString(count, 16));
            
            i++;
        }
        
    }

    public static void Main(string[] args)
    {
        bool uC;
        string UCs;
        uCDef:
            Console.WriteLine("Do you want to use the uc? y/n");
            UCs = Console.ReadLine();
            if (UCs.ToLower() == "y")
            {
                uC = true;
            }
            else if (UCs.ToLower() == "n")
            {
                uC = false;
            }
            else
            {
                Console.WriteLine("Not valid input");
                goto uCDef;
            }

        
        
        bool TH = false;
        string THs;
        
        THDef:
            Console.WriteLine("Do you want to use two halfs? y/n");
            THs = Console.ReadLine();
            if (THs.ToLower() == "y")
            {
                TH = true;
            }
            else if (THs.ToLower() == "n")
            {
                TH = false;
            }
            else
            {
                Console.WriteLine("Not valid input");
                goto THDef;
            }

        Console.WriteLine("Write the background name");
        string name = Console.ReadLine();
        Console.Clear();
        Console.WriteLine("Trying to open " + name);

        byte[] data = new byte[0];
        byte[] data2 = new byte[0];
        if (TH)
        {
            if (!File.Exists(name + ".ho.nam"))
            {
                Console.WriteLine("can't find background " + name);
                Console.ReadKey();
                Environment.Exit(0);
            }

            data = File.ReadAllBytes(name + ".ho.nam");
            if (uC) for (int j = 0; j < data.Length - 64; j++)
            {
                data[j] += 4;
            }

            if (!File.Exists(name + ".ht.nam"))
            {
                Console.WriteLine("can't find background " + name);
                Console.ReadKey();
                Environment.Exit(0);
            }

            data2 = File.ReadAllBytes(name + ".ht.nam");
            if (uC) for (int j = 0; j < data2.Length - 64; j++)
            {
                data2[j] += 4;
            }
        }
        else
        {
            if (!File.Exists(name + ".nam"))
            {
                Console.WriteLine("can't find background " + name);
                Console.ReadKey();
                Environment.Exit(0);
            }

            data = File.ReadAllBytes(name + ".nam");
            if (uC) for (int j = 0; j < data.Length - 64; j++)
            {
                data[j] += 4;
            }

            data2 = new byte[1024];
        }
        OrFLen += data.Length + data2.Length;
        Console.WriteLine("Background " + name + " opened successfully, it's " + OrFLen + " bytes long");
        byte[] Fdata = data.Concat(data2).ToArray();
        Compress(Fdata);
        if (OrFLen > ResultFile.Count)
        {
            Console.WriteLine("Compressing successfull! The compressed file is a " + (((float)(ResultFile.Count) / (float)(OrFLen)) * 100) + "% from the original");
            File.WriteAllBytes(name + ".cbg", ResultFile.ToArray());
        }
        else
        {
            Console.WriteLine("Compressing failed! The compressed file is a " + ((1 - (float)(ResultFile.Count) / (float)(OrFLen)) * 100) + "% from the original");
            File.WriteAllBytes(name + ".cbg", Fdata);
        }
        Console.ReadKey();
    }
}